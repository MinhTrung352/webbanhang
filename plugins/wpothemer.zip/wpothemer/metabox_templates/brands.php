
<p class="wpo_section ">
	<?php 
		$brand_link = array(
            'id'    => 'brand_link',
            'title' => 'Link brand',
            'des'   => '(Enter link band)'
        );
        $mb->addTextElement( $brand_link );
	?>
</p>