<div id="wpo-post" class="wpo-metabox">
    <div class="wpo-meta active" id="genaral">
        <div class="wpo-meta">
            <p class="wpo_section wpo-gallery">
                <?php $mb->addGalleryElement(); ?>
            </p>           
        </div>
    </div>
</div>