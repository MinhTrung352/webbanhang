<?php

class WPBakeryShortCode_Layerslider_Vc extends WPBakeryShortCode {


}